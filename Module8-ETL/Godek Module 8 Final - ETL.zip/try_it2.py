import csv
import yaml
import mysql.connector

path = r'C:\Users\markg\OneDrive\Data Engineering Course\Module 8 Final - ETL\2020MRTSsales.csv'
# a toy dataset
#path = r'C:\Users\markg\OneDrive\Data Engineering Course\Module 8 Final - ETL\toyDataset.csv'

def main():

    #get mySQL server configuration from a yaml file
    db = yaml.safe_load(open('try_it2.yaml'))
    config = {
        'user': db['user'],
        'password': db['password'],
        'host': db['host'],
        #'database': db['db'],
        'auth_plugin': 'mysql_native_password'
    }

    #a function which creates a datanase from a csv file
    def createDB():
        cnx = mysql.connector.connect(**config)
        cursor = cnx.cursor()
        cursor.execute("SHOW DATABASES")
        dbs = []

        for x in cursor:
            dbs.append(x[0])
        #print(dbs) # print databases to terminal
        if 'Sales' not in dbs:
            try:
                cursor.execute("CREATE DATABASE Sales")
            except:
                print('Sales database exists')

        cursor.close()
        cnx.close()

    #a function that inserts entries into a table called 'Sales2020'
    def loadDB():
        with open(path) as file:
            cnx = mysql.connector.connect(**config)
            cursor = cnx.cursor()

            query = (f'USE Sales;')
            cursor.execute(query)

            query = (f'DROP TABLE IF EXISTS Sales2020;')
            cursor.execute(query)

            query = (f'CREATE TABLE Sales2020 (BusinessType varchar(255) NOT NULL, Jan2020 int, Feb2020 int, Mar2020 int, Apr2020 int, May2020 int, Jun2020 int, Jul2020 int, Aug2020 int, Sep2020 int, Oct2020 int, Nov2020 int, Dec2020 int, TOTAL2020 int, PRIMARY KEY (`BusinessType`));')
            cursor.execute(query)

            csv_reader = csv.reader(file)
            #ideas from https://stackoverflow.com/questions/38134503/csv-file-to-sql-insert-statement
            header = next(csv_reader)
            headers = map((lambda x: '`' + x + '`'), header)
            insert = 'INSERT INTO Sales2020  (' + ", ".join(headers) + ") "
            for row in csv_reader:
                key = row[0] #header is string
                row = row[1:] #other values are int
                values = []
                for x in row:
                    values.append(int(x.replace(',', ''))) #remove commas from ints and store in a list
                row = '"' + key + '", ' + ', '.join(str(value) for value in values) #construct a comma-separated string of the ints
                query = insert + 'VALUES (' + row  +");"
                #print(query)
                cursor.execute(query)
                cnx.commit() #commit must be called on the connection when inserting or deleting

        cursor.close()
        cnx.close()

    createDB()
    loadDB()

main()