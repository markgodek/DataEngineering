## Flask and Jinja Web Server

## jrw@mit.edu

Add Bootstrap Navigation and image upload
New routes addbook, addimage
